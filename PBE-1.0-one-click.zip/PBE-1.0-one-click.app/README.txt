PBE-1.0-one-click 1.0

- Mac: launch PBE-1.0-one-click.app
- Linux: launch PBE-1.0-one-click.sh
- Windows: launch PBE-1.0-one-click.bat

This distribution was built May 05, 2012.
